<?php

// Include logo
qi_template_part( 'header', 'templates/parts/logo' );

// Include main navigation
qi_template_part( 'header', 'templates/parts/navigation' );
