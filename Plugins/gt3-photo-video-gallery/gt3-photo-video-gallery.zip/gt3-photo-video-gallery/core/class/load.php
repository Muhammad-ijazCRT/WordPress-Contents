<?php
	if ( ! defined( 'ABSPATH' ) ) exit;

	require_once 'GT3_EDD_SL_Plugin_Updater.php';
	require_once 'gt3pg_updater.php';
	require_once 'gt3classStd.php';
	require_once 'gt3_el.php';
	require_once 'gt3attr.php';
	require_once 'gt3input.php';
	require_once 'gt3input_color.php';
	require_once 'gt3input_onoff.php';
	require_once 'gt3options.php';
	require_once 'gt3select.php';
	require_once 'gt3textarea.php';

	require_once 'gt3panel_select.php';
	require_once 'gt3panel_input.php';
	require_once 'gt3panel_input_color.php';
	require_once 'gt3panel_control.php';
	require_once 'gt3pg_admin_mix_tab_control.php';
	require_once 'fix_windows_edd.php';



